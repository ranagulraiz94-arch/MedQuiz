MedQuiz — Cell Pathology prototype

This is a small mobile-first, offline-ready web app prototype.
Included: 8 MCQs transcribed from page 1 of the uploaded scan, Practice Mode, Exam Mode, scoring, and review.

How to test on Android:
1. Extract this ZIP on a computer or upload the folder to a static hosting service (for example GitHub Pages).
2. Open the hosted HTTPS URL in Chrome on your Android phone.
3. In Chrome menu (⋮), choose "Add to Home screen" or "Install app".
Note: Service workers/PWA installation generally require HTTPS or localhost. Opening index.html directly from a file manager may allow the quiz to run, but offline installation features may not activate.

Transcription note:
Question 1's option E is unclear/not visible in the source scan and is flagged in the app. Please verify it against the book before relying on it.
